classdef InEKF < handle   
    properties
        mu;                 % Pose Mean
        Sigma;              % Pose Sigma
        gfun;               % Motion model function
        mu_pred;             % Mean after prediction step
        Sigma_pred;          % Sigma after prediction step
        mu_cart;
        sigma_cart;
        W;                  % Motion model noise
        V;                  % measurment model noise
    end
    
    methods
        function obj = InEKF(sys, init)
            obj.gfun = sys.gfun;
            obj.mu = init.mu;
            obj.Sigma = init.Sigma;
            obj.W = sys.W;
            obj.V = sys.V;
        end
        
        %% Complete prediction function
        function prediction(obj, u)
            state(1) = obj.mu(1,3);
            state(2) = obj.mu(2,3);
            state(3) = atan2(obj.mu(2,1), obj.mu(1,1));
            H_prev = obj.posemat(state);
            state_pred = obj.gfun(state, u);
            H_pred = obj.posemat(state_pred);
            
            u_se2 = logm(H_prev \ H_pred); % lie algebra

            % Propagate mean and covairance (You need to compute adjoint AdjX)
            obj.propagation(u_se2, AdjX);
        end
        
        %% Complete propagation function
        function propagation(obj, u, AdjX)
            
        end
        
        %% Complete correction function
        function correction(obj, Y, Y2, id, id2)
            global FIELDINFO;
            % Positions of observed given landmarks
            landmark_x = FIELDINFO.MARKER_X_POS(id);
            landmark_y = FIELDINFO.MARKER_Y_POS(id);       
            landmark_x2 = FIELDINFO.MARKER_X_POS(id2);
            landmark_y2 = FIELDINFO.MARKER_Y_POS(id2);
            
        end
        
        function H = posemat(obj,state)
            x = state(1);
            y = state(2);
            h = state(3);
            % construct a SE(2) matrix element
            H = [...
                cos(h) -sin(h) x;
                sin(h)  cos(h) y;
                     0       0 1];
        end
    end
end
