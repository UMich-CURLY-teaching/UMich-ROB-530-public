%% (Extra credits) Complete function that maps mean and covariance from lie algebra to Cartesian coordinate
function lieTocartesian(filter)

end
  